package com.example.appv2;

import android.widget.EditText;
import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Design {

	public EditText toBody;
	public EditText sendBody;
	
	public Design()
	{
		
	}
}
