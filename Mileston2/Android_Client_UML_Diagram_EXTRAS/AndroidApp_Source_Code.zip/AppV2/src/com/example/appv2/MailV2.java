package com.example.appv2;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
public class MailV2{
	
	private String _to = "pollserverv2020@gmail.com";
	public MailV2(String pollid, String body)
	{
		SendEmail(_to, pollid, body);
	}
	
	public MailV2(String to, String sub, String body)
	{
		SendEmail(to, sub, body);
	}
	
	public void SendEmail(String email, String subject, String message)
	{
		int conditionalVar = 0;
		if(conditionalVar==0)
		{
			
		
			final String username = "pollserverv2020@gmail.com";
			final String password = "pollsrv2020";
	 
			Properties props = new Properties();
			props.put("mail.smtp.auth", "true");
			props.put("mail.smtp.starttls.enable", "true");
			props.put("mail.smtp.host", "smtp.gmail.com");
			props.put("mail.smtp.port", "587");
	 
			Session session = Session.getInstance(props,
			  new javax.mail.Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(username, password);
				}
			  });
	 
			try {
	 
				Message message1 = new MimeMessage(session);
				message1.setFrom(new InternetAddress("from-email@gmail.com"));
				message1.setRecipients(Message.RecipientType.TO,
					InternetAddress.parse(email));
				message1.setSubject(subject);
				message1.setText(message);
	 
				Transport.send(message1);
	 
				//System.out.println("Mail sent.");
				conditionalVar = 1;
	 
			} catch (MessagingException e) {
				throw new RuntimeException(e);
				}
			}
		
		}
	public void sendmine(String to, String body)
	{
		SendEmail(to,"PollServer",body);
	}
	
}
