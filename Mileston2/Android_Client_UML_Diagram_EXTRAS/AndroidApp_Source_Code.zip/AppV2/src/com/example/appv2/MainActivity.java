package com.example.appv2;


import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.security.SecureRandom;
import java.math.BigInteger;

public class MainActivity extends Activity {

	private SecureRandom random = new SecureRandom();	
	private EditText toBody;
	private EditText sendBody;
	private String voterID;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		TextView v = (TextView) findViewById(R.id.textView1);
		toBody = (EditText) findViewById(R.id.toBody);
		sendBody = (EditText) findViewById(R.id.SendBody);
		Button b = (Button) findViewById(R.id.button1);
		voterID = nextSessionId();
		b.setOnClickListener(new OnClickListener() {
			
		
		@Override
			public void onClick(View v) {
			
			String to;
			String message;
			to = toBody.getText().toString();
			message = sendBody.getText().toString();
			Inner n = new Inner(to,message);
			n.start();
			
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	public static void viewTouch()
	{
		
		//sendBody.setText(toBody.getText().toString());
	}
	
	public class Inner extends Thread
	{
		String to;
		String message;
		
		Inner(){
			
		}
		
		Inner(String t, String m){
			to = t;
			message = m;
		}
		
		public void run()
		{
			if(to.isEmpty()||message.isEmpty())
			{
				System.out.print("NOTHING");
			}
			else
			{
				MailV2 m = new MailV2(to+"-"+voterID,message);
			}
			
		}
	}
	
	public String nextSessionId()
	  {
	    return new BigInteger(130, random).toString(32);
	  }

}
